<?php

namespace Bookkeeper\Http\Requests;

class TransactionUpdate extends TransactionStore
{

}
