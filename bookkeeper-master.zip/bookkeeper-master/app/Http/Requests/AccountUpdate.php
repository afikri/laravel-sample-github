<?php

namespace Bookkeeper\Http\Requests;

class AccountUpdate extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'accounts.edit';
}
