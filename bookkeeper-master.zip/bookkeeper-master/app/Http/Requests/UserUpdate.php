<?php

namespace Bookkeeper\Http\Requests;

class UserUpdate extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'users.edit';
}
