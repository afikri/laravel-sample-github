<?php

namespace Bookkeeper\Http\Requests;

class ListUpdate extends ListStore
{

}
