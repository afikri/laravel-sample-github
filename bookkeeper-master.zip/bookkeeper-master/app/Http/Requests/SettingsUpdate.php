<?php

namespace Bookkeeper\Http\Requests;

class SettingsUpdate extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'settings.edit';
}
