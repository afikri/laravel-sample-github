<?php

namespace Bookkeeper\Http\Requests;

class TagUpdate extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'tags.edit';
}
