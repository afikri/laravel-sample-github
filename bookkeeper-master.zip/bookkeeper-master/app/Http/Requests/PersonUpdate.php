<?php

namespace Bookkeeper\Http\Requests;

class PersonUpdate extends PersonStore
{

}
