<?php

namespace Bookkeeper\Http\Requests;

class PersonStore extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'people.create';
}
