<?php

namespace Bookkeeper\Http\Requests;

class JobStore extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'jobs.create';
}
