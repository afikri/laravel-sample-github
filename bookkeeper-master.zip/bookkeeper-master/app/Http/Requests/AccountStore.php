<?php

namespace Bookkeeper\Http\Requests;

class AccountStore extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'accounts.create';
}
