<?php

namespace Bookkeeper\Http\Requests;

class ClientUpdate extends ClientStore
{

}
