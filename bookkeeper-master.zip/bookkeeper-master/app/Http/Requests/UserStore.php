<?php

namespace Bookkeeper\Http\Requests;

class UserStore extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'users.create';
}
