<?php

namespace Bookkeeper\Http\Requests;

class TransactionStore extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'transactions.create';
}
