<?php

namespace Bookkeeper\Http\Requests;

class ProfileUpdate extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'profile.edit';
}
