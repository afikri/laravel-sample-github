<?php

namespace Bookkeeper\Http\Requests;

class JobUpdate extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'jobs.edit';
}
