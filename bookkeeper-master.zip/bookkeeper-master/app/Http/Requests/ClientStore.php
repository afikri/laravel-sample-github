<?php

namespace Bookkeeper\Http\Requests;

class ClientStore extends BookkeeperRequest
{
    /* @var string */
    protected $configKey = 'clients.create';
}
