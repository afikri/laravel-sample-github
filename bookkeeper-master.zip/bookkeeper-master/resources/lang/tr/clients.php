<?php

return [

    'title' => 'Firmalar',
    'search' => 'Firma Ara',
    'all' => 'Tüm Firmalar',
    'self' => 'Firma',

    'index' => 'Firmaları Yönet',
    'create' => 'Yeni Firma',
    'created' => 'Firma oluşturuldu.',
    'edit' => 'Firmayı Düzenle',
    'edited' => 'Firma düzenlendi.',
    'destroy' => 'Firmayı Sil',
    'destroyed' => 'Firma silindi.',
    'no_clients' => 'Firma bulunamadı.',

];
