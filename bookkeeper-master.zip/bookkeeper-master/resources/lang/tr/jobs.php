<?php

return [

    'title' => 'İşler',
    'search' => 'İş Ara',
    'all' => 'Tüm İşler',
    'self' => 'İş',

    'index' => 'İşleri Yönet',
    'create' => 'Yeni İş',
    'created' => 'İş oluşturuldu.',
    'edit' => 'İşi Düzenle',
    'edited' => 'İş düzenlendi.',
    'destroy' => 'İşi Sil',
    'destroyed' => 'İş silindi.',
    'no_jobs' => 'İş bulunamadı.',
    'deleted_offer' => 'Teklif silindi.',

];
