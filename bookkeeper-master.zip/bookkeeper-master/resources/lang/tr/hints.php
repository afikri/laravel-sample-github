<?php

return [

    'email' => 'Lütfen geçerli bir e-posta adresi giriniz.',
    'password' => 'Kuvvetli bir şifre seçin!',
    'password_confirmation' => 'Şifrenizi onaylayın.',

];