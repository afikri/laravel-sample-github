<?php

return [
    'edit' => 'Ayarları Düzenle',
    'edited' => 'Ayarlar düzenlendi. Değişikliklerin yürürlüğe girmesi birkaç dakika sürebilir.',
    'default_vat_percentage' => 'Öntanımlı KDV Yüzdesi'
];
