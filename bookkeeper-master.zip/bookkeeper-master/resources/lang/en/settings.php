<?php

return [
    'edit' => 'Edit Settings',
    'edited' => 'Edited settings. It might take a couple of minutes for changes to take effect.',
    'default_vat_percentage' => 'Default VAT Percentage'
];
