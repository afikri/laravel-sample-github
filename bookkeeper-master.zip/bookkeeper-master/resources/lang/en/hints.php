<?php

return [

    'email' => 'Please enter a valid e-mail address.',
    'password' => 'Choose a strong password!',
    'password_confirmation' => 'Confirm your password.',

];