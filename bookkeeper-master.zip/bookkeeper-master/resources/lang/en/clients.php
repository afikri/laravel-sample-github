<?php

return [

    'title' => 'Companies',
    'search' => 'Search Companies',
    'all' => 'All Companies',
    'self' => 'Company',

    'index' => 'Manage Companies',
    'create' => 'New Company',
    'created' => 'Company was created.',
    'edit' => 'Edit Company',
    'edited' => 'Company was edited.',
    'destroy' => 'Delete Company',
    'destroyed' => 'Deleted company.',
    'no_companies' => 'No companies were found.',

];
