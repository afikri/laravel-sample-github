<?php

return [

    'title' => 'Jobs',
    'search' => 'Search Jobs',
    'all' => 'All Jobs',
    'self' => 'Job',

    'index' => 'Manage Jobs',
    'create' => 'New Job',
    'created' => 'Job was created.',
    'edit' => 'Edit Job',
    'edited' => 'Job was edited.',
    'destroy' => 'Delete Job',
    'destroyed' => 'Deleted job.',
    'no_jobs' => 'No jobs were found.',
    'deleted_offer' => 'Deleted offer.',

];
